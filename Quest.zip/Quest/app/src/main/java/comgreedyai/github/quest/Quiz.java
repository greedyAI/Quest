package comgreedyai.github.quest;

import java.util.LinkedList;

/**
 * Created by Waley on 2017/12/12.
 */

public class Quiz {

    private String id;
    private String name;

    public Quiz(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
